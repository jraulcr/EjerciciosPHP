<!DOCTYPE html>
<html lang="es">

    <head>
        <title>Conversor de euros a pesetas</title>
    </head>

    <body>

        <h1>Conversor de euros a pesetas</h1>

        <form action="practica5a-resultados.php" method="post">

            <p>Cantidad en euros:
                <input type="text" name="euros" size="10">
                <input type="submit" name="enviar" value="convertir"></p>

        </form>

    </body>
</html>
