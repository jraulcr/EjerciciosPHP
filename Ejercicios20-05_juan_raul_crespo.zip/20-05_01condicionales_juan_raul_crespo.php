<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Condicional</title>
    </head>
    <body>
        <?php
        $a = 10;
        $b = 5;

        if ($a > $b) {
            echo " El mayor es A " . $a;
        } else {
            echo " El mayor es B " . $b;
        }
        ?>
    </body>
</html>
