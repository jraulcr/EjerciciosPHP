<?php
$animal = array(
 array("Perro", "Gato"),
 array("Lombriz", "Burro"),
 array("Murciélago", "Cocodrilo")
 );
echo $animal[2][1];
echo $animal[0][0];

/*
$animal [0] [0] = "Perro"; $animal [0] [1] = "Gato";
$animal [1] [0] = "Lombriz"; $animal [1] [1] = "Burro";
$animal [2] [0] = "Murciélago"; $animal [2] [1] = "Cocodrilo";
*/
?>


