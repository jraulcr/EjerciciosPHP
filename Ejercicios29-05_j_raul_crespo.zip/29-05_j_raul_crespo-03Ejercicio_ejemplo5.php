<?php
$animal[0][0][0] = "Perro";
$animal[0][0][1] = "Gato";
$animal[0][0][2] = "Lombriz";
$animal[1][0][0] = "Burro";
$animal[1][0][1] = "Murciélago";
$animal[1][0][2] = "Cocodrilo";
echo "<br/>&nbsp;&nbsp;&nbsp;" . $animal[1][0][1];
echo "<br/>&nbsp;&nbsp;&nbsp;" . $animal[0][0][3];

?>


