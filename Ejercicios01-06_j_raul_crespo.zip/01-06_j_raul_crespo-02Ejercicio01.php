<?php
//Ejemplo de PHP sort() y rsort() para ordenar un array
//
//orden ascendente
sort($arraynumerico);
var_export($arraynumerico);

//orden descendente
echo "<br>";
rsort($arraynumerico);
var_export($arraynumerico);
?>
